<?php
if(!defined('IS_IN_MODULE')) { die("NO DIRECT FILE ACCESS!"); }
?>

<?php
class Mobile {
    function info() {
      include ('info.php');
    }
    function slide() {
      include ('slide.php');
    }
}
?>
