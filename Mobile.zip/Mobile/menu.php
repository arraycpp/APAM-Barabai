<li class="<?php if ($params['module']=="Mobile") {echo "active"; } ?>">
    <a href="javascript:void(0);" class="menu-toggle">
        <i class="material-icons">phonelink_setup</i>
        <span>Mobile</span>
    </a>
    <ul class="ml-menu">
        <li class="<?php if ($params['module']=="Mobile" && $params['page']=="info") {echo "active"; } ?>">
            <a href="<?php echo URL; ?>/index.php?module=Mobile&page=info">
                Info
            </a>
        </li>
        <li class="<?php if ($params['module']=="Mobile" && $params['page']=="slide") {echo "active"; } ?>">
            <a href="<?php echo URL; ?>/index.php?module=Mobile&page=slide">
                Slide
            </a>
        </li>
    </ul>
</li>
