<div class="card">
  <div class="header">
      <h2>Data Gambar</h2>
  </div>
  
                        <div class="body">
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#slide" aria-controls="settings" role="tab" data-toggle="tab">Data Slide</a></li>
                                <li role="presentation"><a href="#tambah" aria-controls="settings" role="tab" data-toggle="tab">Tambah</a></li>
                            </ul>
                        </div>
						<div class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active" id="slide">
                              <div class="panel-group" id="accordion">
                                <div class="panel panel-default" style="border: none !important;">
                                    <div class="panel-body">
                                     <table class="table table-bordered table-striped table-hover display nowrap" width="100%">
        <thead>
            <tr>
                <th>Keterangan</th>
                <th>Gambar</th>
                <th>Tanggal Unggah</th> 
            </tr>
        </thead>
        <tbody>
        <?php
            $sql = "SELECT * from appslide order by tgl_update desc";
            $query = query($sql);
            while($row = fetch_array($query)) {
        ?>
            <tr>
                <td><?php echo $row['keterangan'];?></td>
                <td><img src="<?php echo URLIMG.'/'.$row['gambar'];?>" width="200px" height="100px"/></td>
                <td><?php echo $row['tgl_update'];?></td> 
            </tr>
        <?php
            }
        ?>
        </tbody>
    </table>
  
									</div>
                                </div>
                              </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade in" id="tambah">
                                <div class="body">
                                <?php
      	if (isset($_POST['simpan'])) {
			$date=date('y-m-d h:m:i');
            if($_FILES['file']['name'] !=='') {
                $tmp_name = $_FILES["file"]["tmp_name"];
                $namefile = $_FILES["file"]["name"];
                $explode = explode(".", $namefile);
                $ext = end($explode);
                $image_name = $_SESSION['username']."-".time().".".$ext;
                move_uploaded_file($tmp_name,WEBAPPS."/images/".$image_name);
            } else {
              $image_name = '-';
            }

          	$insert = query("INSERT INTO `slideapp`
              (
                `id_slide`, `gambar`, `keterangan`, `tgl_update`
              )
                VALUES
              (
                NULL, '{$image_name}', '{$_POST['keterangan']}', '{$date}'
              )
            ");

        };
        ?>
		<form class="form-horizontal" method="post" action=""  enctype="multipart/form-data">
                    <div class="form-group">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4">
                            <div class="form">
                              <img id="image_upload_preview" width="200px" style="-webkit-border-radius: 50%; -moz-border-radius: 50%; -ms-border-radius: 50%; border-radius: 50%;" src="<?php echo URL; ?>/assets/images/nophoto.jpg" onclick="upload_berkas()" style="cursor:pointer;" alt="User" />
                              <br/>
                              <input name="file" id="inputFile" type="file" style="display:none;"/>
                            </div>
                        </div>
                        <div class="col-sm-4"></div>
                    </div>
                    <div class="form-group">
                        <label for="keterangan" class="col-sm-2 control-label">Keterangan</label>
                        <div class="col-sm-10">
                            <div class="form-line">
                                <input type="text" class="form-control" id="keterangan" name="keterangan" placeholder="Keterangan" required>
                            </div>
                        </div>
                    </div>
           
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" name="simpan" class="btn btn-danger" value="SIMPAN" />
                        </div>
                    </div>
                </form>
            
			
								
								  
								</div>
                            </div>
                        </div>
                    					
	 
</div>
