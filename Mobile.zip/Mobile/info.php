<div class="card">
  <div class="header">
      <h2>Data Gambar</h2>
  </div>
  
                        <div class="body">
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#slide" aria-controls="settings" role="tab" data-toggle="tab">Data Slide</a></li>
                                <li role="presentation"><a href="#tambah" aria-controls="settings" role="tab" data-toggle="tab">Tambah</a></li>
                            </ul>
                        </div>
						<div class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active" id="slide">
                              <div class="panel-group" id="accordion">
                                <div class="panel panel-default" style="border: none !important;">
                                    <div class="panel-body">
                                     <table class="table table-bordered table-striped table-hover display nowrap" width="100%">
        <thead>
            <tr>
                <th>Judul</th> 
                <th>Tanggal</th> 
                <th>Admin</th> 
            </tr>
        </thead>
        <tbody>
        <?php
            $sql = "SELECT * from appinfo order by tgl_info desc";
            $query = query($sql);
            while($row = fetch_array($query)) {
        ?>
            <tr>
                <td><?php echo $row['judul_info'];?></td> 
                <td><?php echo $row['tgl_info'];?></td> 
                <td><?php echo $row['admin'];?></td> 
            </tr>
        <?php
            }
        ?>
        </tbody>
    </table>
  
									</div>
                                </div>
                              </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade in" id="tambah">
                                <div class="body">
                                <?php
      	if (isset($_POST['simpan'])) {
			$date=date('y-m-d h:m:i');

          	$insert = query("INSERT INTO `appinfo`
              (
                `id_info`, `judul_info`, `isi_info`, `admin`, `sumber_info`, `tgl_info`
              )
                VALUES
              (
                NULL,'{$_POST['judul_info']}', '{$_POST['isi_info']}','{$_SESSION['username']}','{$_POST['sumber_info']}','{$date}'
              )
            ");

        };
        ?>
		<form class="form-horizontal" method="post" action=""  enctype="multipart/form-data">
                    <div class="form-group">
                        <div class="col-sm-4"></div>
						
                    <div class="col-sm-4"></div>
                    </div>
                    <div class="form-group">
                        <label for="judul_info" class="col-sm-2 control-label">Judul</label>
                        <div class="col-sm-10">
                            <div class="form-line">
                                <input type="text" class="form-control" id="judul_info" name="judul_info" placeholder="Judul">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="judul_info" class="col-sm-2 control-label">isi</label>
                        <div class="col-sm-10">
                            <div class="form-line">
                                <textarea class="tiny form-control" id="isi_info" name="isi_info"></textarea> 
                            </div>
                        </div>
                    </div>
					 <div class="form-group">
                        <label for="judul_info" class="col-sm-2 control-label">Sumber</label>
                        <div class="col-sm-10">
                            <div class="form-line">
                                <input type="text" class="form-control" id="sumber_info" name="sumber_info" placeholder="http://www.kemkes.go.id/" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" name="simpan" class="btn btn-danger" value="SIMPAN" />
                        </div>
                    </div>
                </form>
            
			
								
								  
								</div>
                            </div>
                        </div>
                    					
	 
</div>


<script src="assets/plugins/tinymce/tinymce.min.js"></script>
<script type="text/javascript">// <![CDATA[
tinymce.init({
                selector: "textarea",
                plugins: [
                        "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                        "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                        "table contextmenu directionality emoticons template textcolor paste fullpage textcolor"
                ],

                toolbar1: "newdocument fullpage | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
                toolbar2: "cut copy paste | searchreplace | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image media code | inserttime preview | forecolor backcolor",
                toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",

                menubar: false,
                toolbar_items_size: 'small',

                style_formats: [
                        {title: 'Bold text', inline: 'b'},
                        {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                        {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                        {title: 'Example 1', inline: 'span', classes: 'example1'},
                        {title: 'Example 2', inline: 'span', classes: 'example2'},
                        {title: 'Table styles'},
                        {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
                ],

                templates: [
                        {title: 'Test template 1', content: 'Test 1'},
                        {title: 'Test template 2', content: 'Test 2'}
                ]
        });
// ]]></script>